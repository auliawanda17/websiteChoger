<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller {

	public function index()
	{
		$this->load->view('header');
		$this->load->view('produk');
		$this->load->view('footer');
	}

	public function permen()
	{
		$this->load->view('header');
		$this->load->view('permen');
		$this->load->view('footer');
	}

	public function snack()
	{
		$this->load->view('header');
		$this->load->view('snack');
		$this->load->view('footer');
	}

	public function minuman()
	{
		$this->load->view('header');
		$this->load->view('minuman');
		$this->load->view('footer');
	}

	public function detail_permen1()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen1');
		$this->load->view('footer');
	}

	public function detail_permen2()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen2');
		$this->load->view('footer');
	}

	public function detail_permen3()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen3');
		$this->load->view('footer');
	}

	public function detail_permen4()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen4');
		$this->load->view('footer');
	}

	public function detail_permen5()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen5');
		$this->load->view('footer');
	}

	public function detail_permen6()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen6');
		$this->load->view('footer');
	}

	public function detail_permen7()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen7');
		$this->load->view('footer');
	}

	public function detail_permen8()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen8');
		$this->load->view('footer');
	}

	public function detail_permen9()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/permen9');
		$this->load->view('footer');
	}

	public function detail_minuman1()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman1');
		$this->load->view('footer');
	}

	public function detail_minuman2()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman2');
		$this->load->view('footer');
	}

	public function detail_minuman3()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman3');
		$this->load->view('footer');
	}

	public function detail_minuman4()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman4');
		$this->load->view('footer');
	}

	public function detail_minuman5()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman5');
		$this->load->view('footer');
	}

	public function detail_minuman6()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman6');
		$this->load->view('footer');
	}

	public function detail_minuman7()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman7');
		$this->load->view('footer');
	}

	public function detail_minuman8()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman8');
		$this->load->view('footer');
	}

	public function detail_minuman9()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/minuman9');
		$this->load->view('footer');
	}

	public function detail_snack1()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack1');
		$this->load->view('footer');
	}

	public function detail_snack2()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack2');
		$this->load->view('footer');
	}

	public function detail_snack3()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack3');
		$this->load->view('footer');
	}

	public function detail_snack4()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack4');
		$this->load->view('footer');
	}

	public function detail_snack5()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack5');
		$this->load->view('footer');
	}

	public function detail_snack6()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack6');
		$this->load->view('footer');
	}

	public function detail_snack7()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack7');
		$this->load->view('footer');
	}

	public function detail_snack8()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack8');
		$this->load->view('footer');
	}

	public function detail_snack9()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack9');
		$this->load->view('footer');
	}

	public function detail_snack10()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack10');
		$this->load->view('footer');
	}

	public function detail_snack11()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack11');
		$this->load->view('footer');
	}

	public function detail_snack12()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack12');
		$this->load->view('footer');
	}

	public function detail_snack13()
	{
		$this->load->view('header');
		$this->load->view('detail_produk/snack13');
		$this->load->view('footer');
	}
}
